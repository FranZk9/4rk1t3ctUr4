======================README======================
NOMBRE: FRANCISCA ANAIS VALENZUELA SALAZAR
ROL: 201973546-2
==================================================
La tarea fue completamente hecha en linux.

Para compilar y ejecutar escribir el comando
"make run" en terminal.

Para borrar el archivo generado usar "make clean".

